CreatorHub browser prototype
1. Unzip the folder.
2. Open index.html in Chrome, Edge, Firefox, or Safari.
3. The buttons, modal login/signup, scrolling sections, and follow buttons work as a front-end demo.
This is a prototype, not a production service. Production needs a backend, secure authentication, database, video storage/transcoding, moderation, age/identity verification, payments, privacy controls, and legal compliance.
